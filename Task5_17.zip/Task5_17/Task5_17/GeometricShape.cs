﻿using System;
using System.Drawing;

namespace Task5_17
{
    public abstract class GeometricShape : Figure
    {
        public String name { get; set; }
        protected Point[] points;
        private Point center;
        private int figureDegree; 
        public double Size()
        {
            return Math.Sqrt((points[0].X - points[2].X) * (points[0].X - points[2].X) +
                             (points[0].Y - points[2].Y) * (points[0].Y - points[2].Y)) * 
                   Math.Sqrt((points[1].X - points[3].X) * (points[1].X - points[3].X) +
                (points[1].Y - points[3].Y) * (points[1].Y - points[3].Y))/2;
        }

        public void Move(double dx, double dy)
        {
            for (int i = 0; i < points.Length; i++)
            {
                points[i] = new Point((int) (points[i].X + dx), (int) (points[i].Y + dy));
            }
            center = new Point((int) (center.X + dx), (int) (center.Y + dy));
        }

        public bool IsFlatFigure()
        {
            return figureDegree <= 1;
        }

        public double LargestDiagonal()
        {
            double d1 = Math.Sqrt((points[0].X - points[2].X) * (points[0].X - points[2].X) +
                                  (points[0].Y - points[2].Y) * (points[0].Y - points[2].Y));
            double d2 = Math.Sqrt((points[1].X - points[3].X) * (points[1].X - points[3].X) +
                                  (points[1].Y - points[3].Y) * (points[1].Y - points[3].Y));
            if (d1 >= d2)
            {
                return d1;
            }
            return d2;
        }
    }
}