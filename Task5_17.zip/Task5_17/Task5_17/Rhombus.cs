﻿using System;
using System.Drawing;

namespace Task5_17
{
    public class Rhombus : GeometricShape
    {
        private double largestUngle;
        private Color _color;

        public Rhombus(double largestUngle, Color color)
        {
            this.largestUngle = largestUngle;
            _color = color;
        }

        public bool isSquare()
        {
            return largestUngle == 90;
        }

        public double RadiusInscribedCircle()
        {
            double d1 = Math.Sqrt((points[0].X - points[2].X) * (points[0].X - points[2].X) +
                                  (points[0].Y - points[2].Y) * (points[0].Y - points[2].Y));
            double d2 = Math.Sqrt((points[1].X - points[3].X) * (points[1].X - points[3].X) +
                                  (points[1].Y - points[3].Y) * (points[1].Y - points[3].Y));
            return (d1 * d2) / (2 * Math.Sqrt(d1 * d1 + d2 * d2));
        } 
    }
}