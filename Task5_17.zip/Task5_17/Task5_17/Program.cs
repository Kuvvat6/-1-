﻿using System;
using System.Collections.Generic;
using System.Drawing;

namespace Task5_17
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Figure> figures = new List<Figure>();
            figures.Add(new Rhombus(90, Color.Gray));
            figures.Add(new Rhombus(120, Color.Red));
            foreach (Rhombus r in figures)
            {
                Console.WriteLine(r.isSquare());
            }
        }
    }
}