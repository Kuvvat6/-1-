﻿using System;

namespace Task5_17
{
    public interface Figure
    {
        String name
        {
            get;
            set;
        }

        double Size();
        void Move(double dx, double dy);
    }
}